"""
Semantic Kernel agent (Anthropic Claude) that connects to a running MCP server (HTTP) and uses its
tools (RAG search + tax calculator) via automatic function calling.

Usage:
    python sk_agent_client.py                                  # interactive chat
    python sk_agent_client.py "Tax on $80k single?"            # one-shot question
    python sk_agent_client.py --url http://myhost:8000/mcp "..."  # custom server URL
"""
import argparse
import asyncio
import os
import sys

from dotenv import load_dotenv
from semantic_kernel.agents import ChatCompletionAgent, ChatHistoryAgentThread
from semantic_kernel.connectors.ai import FunctionChoiceBehavior
from semantic_kernel.connectors.ai.anthropic import AnthropicChatCompletion, AnthropicChatPromptExecutionSettings
from semantic_kernel.connectors.mcp import MCPStreamableHttpPlugin
from semantic_kernel.functions import KernelArguments

load_dotenv()

DEFAULT_MCP_URL = "http://127.0.0.1:8000/mcp"

INSTRUCTIONS = """You are a US federal income tax assistant for tax year 2025.
Rules:
1. For factual questions (rules, limits, credits, deadlines, definitions) ALWAYS call
   search_tax_docs first and base your answer only on the retrieved passages.
2. For tax amount questions, use calculate_federal_tax. Compute taxable income first
   (gross income - standard deduction via get_standard_deduction, unless the user says otherwise).
3. You may call several tools in sequence and refine your search query if results are weak.
4. Cite the section name (e.g. "Section 6") for facts taken from the documents.
5. If the documents do not contain the answer, say so. Never invent figures.
6. You are not a tax advisor; add a brief reminder to verify with the IRS or a professional for decisions.
"""


def build_chat_service() -> AnthropicChatCompletion:
    """Anthropic Claude via Semantic Kernel (needs ANTHROPIC_API_KEY)."""
    return AnthropicChatCompletion(
        ai_model_id=os.getenv("ANTHROPIC_CHAT_MODEL_ID", "claude-sonnet-4-5"),
        api_key="",
    )


def build_settings() -> KernelArguments:
    """Let Claude decide when to call the MCP tools (automatic function calling)."""
    return KernelArguments(
        settings=AnthropicChatPromptExecutionSettings(
            max_tokens=1500,           
            function_choice_behavior=FunctionChoiceBehavior.Auto(),
        )
    )


async def ask(agent: ChatCompletionAgent, thread, question: str):
    """Send a question, print tool calls as they happen, return the updated thread."""
    print("\nAssistant: ", end="", flush=True)
    async for chunk in agent.invoke_stream(messages=question, thread=thread):
        print(chunk.message.content, end="", flush=True)
        thread = chunk.thread
    print()
    return thread


async def main() -> None:
    parser = argparse.ArgumentParser(description="Semantic Kernel + Claude agent using a remote MCP server")
    parser.add_argument("--url", default=os.getenv("MCP_SERVER_URL", DEFAULT_MCP_URL), help="MCP server URL")
    parser.add_argument("question", nargs="*", help="Optional one-shot question (omit for interactive chat)")
    args = parser.parse_args()
    mcp_url = args.url
    one_shot = " ".join(args.question).strip()
    print(f"Connecting to MCP server: {mcp_url}")

    # Connects to the already-running MCP server over HTTP and exposes its tools as a SK plugin
    async with MCPStreamableHttpPlugin(
        name="TaxTools",
        description="US tax knowledge base search and tax calculators",
        url=mcp_url,
    ) as tax_plugin:
        agent = ChatCompletionAgent(
            service=build_chat_service(),
            name="TaxAgent",
            instructions=INSTRUCTIONS,
            plugins=[tax_plugin],
            arguments=build_settings(),
        )
        thread = ChatHistoryAgentThread()

        if one_shot:
            await ask(agent, thread, one_shot)
            return

        print("US Tax Agent (type 'exit' to quit)")
        while True:
            try:
                user = input("\nYou: ").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if user.lower() in {"exit", "quit", ""}:
                break
            thread = await ask(agent, thread, user)


if __name__ == "__main__":
    asyncio.run(main())
