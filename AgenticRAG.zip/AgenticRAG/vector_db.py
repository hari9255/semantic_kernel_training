"""
vector_db.py - single-file vector database for the US tax guide.

Uses Semantic Kernel end to end:
  - HuggingFaceTextEmbedding (sentence-transformers/all-MiniLM-L6-v2, 384 dims)
  - ChromaCollection (persistent, cosine space)

Build the DB:   python vector_db.py --reset
Use elsewhere:  from vector_db import get_collection   (e.g. in mcp_server.py)
"""
import argparse
import asyncio
import os
import re
from dataclasses import dataclass
from typing import Annotated

import pdfplumber
from dotenv import load_dotenv
from semantic_kernel.connectors.ai.hugging_face import HuggingFaceTextEmbedding
from semantic_kernel.connectors.chroma import ChromaCollection
from semantic_kernel.data.vector import DistanceFunction, VectorStoreField, vectorstoremodel

load_dotenv()

# ----------------------------- Config -----------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PDF_PATH = os.getenv("PDF_PATH", os.path.join(BASE_DIR, "US_Tax_Guide_Sample.pdf"))
CHROMA_DIR = os.getenv("CHROMA_DIR", os.path.join(BASE_DIR, "chroma_db"))
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "us_tax_docs")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
EMBEDDING_DIMS = 384  # all-MiniLM-L6-v2 output size


# ----------------------------- Data model -----------------------------
@vectorstoremodel
@dataclass
class TaxChunk:
    id: Annotated[str, VectorStoreField("key")]
    text: Annotated[str, VectorStoreField("data", is_full_text_indexed=True)]
    section: Annotated[str, VectorStoreField("data", is_indexed=True)]
    page: Annotated[int, VectorStoreField("data", is_indexed=True)]
    # A str in the vector field tells Semantic Kernel to embed it automatically on upsert
    embedding: Annotated[
        list[float] | str | None,
        VectorStoreField("vector", dimensions=EMBEDDING_DIMS, distance_function=DistanceFunction.COSINE_SIMILARITY),
    ] = None

    def __post_init__(self):
        if self.embedding is None:
            self.embedding = self.text


def get_embedder() -> HuggingFaceTextEmbedding:
    return HuggingFaceTextEmbedding(ai_model_id=EMBEDDING_MODEL)  # downloaded from HF hub on first use


def get_collection(embedder=None) -> ChromaCollection:
    return ChromaCollection(
        record_type=TaxChunk,
        collection_name=COLLECTION_NAME,
        persist_directory=CHROMA_DIR,
        embedding_generator=embedder or get_embedder(),
    )


# ----------------------------- PDF chunking -----------------------------
MAX_CHARS = 1200       # max characters per chunk
OVERLAP_CHARS = 150    # overlap when a section must be split

# Matches section headings such as "3. Tax Brackets and Standard Deduction"
HEADING_RE = re.compile(r"^(\d{1,2})\.\s+([A-Z][A-Za-z ,&/()-]+)$")
NOISE_RE = re.compile(r"^(Sample US Tax Guide.*|Page \d+)$")


def extract_sections(pdf_path: str) -> list[dict]:
    """Read the PDF and return a list of {section, text, page} dicts."""
    sections: list[dict] = []
    current = None

    with pdfplumber.open(pdf_path) as pdf:
        for page_no, page in enumerate(pdf.pages, start=1):
            if page_no == 1:   # cover page + table of contents -> skip
                continue
            for line in (page.extract_text() or "").splitlines():
                line = line.strip()
                if not line or NOISE_RE.match(line):
                    continue
                m = HEADING_RE.match(line)
                if m:
                    current = {"section": f"{m.group(1)}. {m.group(2)}", "text": "", "page": page_no}
                    sections.append(current)
                elif current is not None:
                    current["text"] += line + "\n"
    return sections


def split_text(text: str, max_chars: int = MAX_CHARS, overlap: int = OVERLAP_CHARS) -> list[str]:
    """Split long section text on line boundaries, keeping a small overlap."""
    text = text.strip()
    if len(text) <= max_chars:
        return [text]

    chunks, lines = [], []
    for line in text.splitlines():
        if lines and len("\n".join(lines)) + len(line) + 1 > max_chars:
            chunks.append("\n".join(lines).strip())
            # carry over trailing whole lines (up to `overlap` chars) as context
            carry, size = [], 0
            for prev in reversed(lines):
                if size + len(prev) > overlap:
                    break
                carry.insert(0, prev)
                size += len(prev)
            lines = carry
        lines.append(line)
    if "\n".join(lines).strip():
        chunks.append("\n".join(lines).strip())
    return chunks


def build_chunks(pdf_path: str) -> list[dict]:
    chunks = []
    for sec in extract_sections(pdf_path):
        for i, piece in enumerate(split_text(sec["text"])):
            # Prefix the section title so each chunk carries its own context
            content = f"{sec['section']}\n{piece}"
            chunks.append(
                {
                    "id": f"{sec['section'].split('.')[0].zfill(2)}-{i}",
                    "text": content,
                    "metadata": {"section": sec["section"], "page": sec["page"], "chunk_index": i},
                }
            )
    return chunks


# ----------------------------- Build -----------------------------
async def build(pdf_path: str, reset: bool = False) -> None:
    chunks = build_chunks(pdf_path)
    records = [
        TaxChunk(id=c["id"], text=c["text"], section=c["metadata"]["section"], page=c["metadata"]["page"])
        for c in chunks
    ]
    print(f"Read {pdf_path}: {len(records)} chunks")
    print(f"Loading embedding model: {EMBEDDING_MODEL}")

    collection = get_collection()
    async with collection:
        if reset and await collection.collection_exists():
            await collection.ensure_collection_deleted()
        await collection.ensure_collection_exists()
        await collection.upsert(records)
        print(f"Stored {len(records)} chunks in '{COLLECTION_NAME}' at {CHROMA_DIR}")

        q = "What is the standard deduction for married filing jointly?"
        print(f"\nTest query: {q}")
        results = await collection.search(values=q, top=2)
        async for r in results.results:
            print(f"  [{r.record.section} | p.{r.record.page} | similarity={1 - r.score:.3f}] {r.record.text[:80]!r}...")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", default=PDF_PATH)
    parser.add_argument("--reset", action="store_true", help="Delete the collection first")
    args = parser.parse_args()
    asyncio.run(build(args.pdf, args.reset))
