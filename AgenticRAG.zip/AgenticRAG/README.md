# US Tax Agentic RAG (Semantic Kernel + ChromaDB + MCP + Claude)

A sample agentic RAG project over a US federal income tax guide (tax year 2025).

- **Vector DB**: ChromaDB, built through Semantic Kernel, with HuggingFace `sentence-transformers/all-MiniLM-L6-v2` embeddings
- **MCP server**: exposes a semantic search tool and tax calculator tools over HTTP
- **Agent client**: a Semantic Kernel `ChatCompletionAgent` using an Anthropic Claude model, calling the MCP tools via automatic function calling

> The sample PDF and tax figures are illustrative and not tax advice. Verify against IRS.gov.

## Architecture

```
US_Tax_Guide_Sample.pdf
        |  vector_db.py (chunk by section, embed with all-MiniLM-L6-v2)
        v
   chroma_db/  <------------------+
                                  | search_tax_docs
                          mcp_server.py  (HTTP, http://127.0.0.1:8000/mcp)
                           tools: search_tax_docs, get_standard_deduction,
                                  calculate_federal_tax
                                  ^
                                  | MCP (streamable HTTP)
                          sk_agent_client.py  (Semantic Kernel agent + Claude)
```

## Project files

| File | Purpose |
|---|---|
| `US_Tax_Guide_Sample.pdf` | Sample 8-page tax guide (the knowledge source) |
| `vector_db.py` | Single-file vector DB: data model, HuggingFace embedder, Chroma collection, PDF chunking, build script |
| `mcp_server.py` | Standalone MCP server (streamable HTTP) with the 3 tools |
| `sk_agent_client.py` | Semantic Kernel agent that connects to the server by URL and uses Claude |
| `requirements.txt` | Python dependencies |
| `.env.example` | Configuration template |

## MCP tools

| Tool | Description |
|---|---|
| `search_tax_docs(query, top_k)` | Semantic search over the guide; returns section, page, similarity, text |
| `get_standard_deduction(filing_status)` | 2025 standard deduction (`single`, `mfj`, `mfs`, `hoh`) |
| `calculate_federal_tax(taxable_income, filing_status)` | 2025 federal tax with marginal/effective rate and bracket breakdown |

## Prerequisites

- Python 3.10+ (3.12 recommended)
- An Anthropic API key
- Internet access on first run (to download the embedding model from HuggingFace, about 90 MB; no HF token needed)

## Setup

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env               # Windows: copy .env.example .env
# edit .env and set ANTHROPIC_API_KEY
```

## Run

**1. Build the vector DB (once, or whenever the PDF or model changes)**

```bash
python vector_db.py --reset
# or with another PDF: python vector_db.py --pdf my_doc.pdf --reset
```

**2. Start the MCP server (terminal 1)**

```bash
python mcp_server.py
# MCP server at http://127.0.0.1:8000/mcp
```

**3. Run the agent (terminal 2)**

```bash
python sk_agent_client.py                                   # interactive chat
python sk_agent_client.py "I'm single and earn $80,000. What is my federal tax?"
python sk_agent_client.py --url http://myhost:8000/mcp "What is the Child Tax Credit?"
```

## Configuration (`.env`)

| Variable | Default | Used by |
|---|---|---|
| `PDF_PATH` | `US_Tax_Guide_Sample.pdf` | `vector_db.py` |
| `CHROMA_DIR` | `./chroma_db` | `vector_db.py`, `mcp_server.py` |
| `COLLECTION_NAME` | `us_tax_docs` | `vector_db.py`, `mcp_server.py` |
| `EMBEDDING_MODEL` | `sentence-transformers/all-MiniLM-L6-v2` | `vector_db.py`, `mcp_server.py` |
| `MCP_HOST` / `MCP_PORT` | `127.0.0.1` / `8000` | `mcp_server.py` |
| `MCP_SERVER_URL` | `http://127.0.0.1:8000/mcp` | `sk_agent_client.py` (or `--url`) |
| `ANTHROPIC_API_KEY` | none (required) | `sk_agent_client.py` |
| `ANTHROPIC_CHAT_MODEL_ID` | `claude-sonnet-5-5` | `sk_agent_client.py` |

The server and the build step must use the same `CHROMA_DIR`, `COLLECTION_NAME` and `EMBEDDING_MODEL`. If you change the embedding model, rebuild with `--reset`.

## Sample questions

- What is the early withdrawal penalty on a 401(k)?
- When is the filing deadline, and how do I get an extension?
- I'm single and earn $80,000 in wages. What is my federal tax? (expected: about $9,049)
- Compare the tax on $100,000 taxable income for single vs married filing jointly.
- I'm single with $95,000 income and contribute $10,000 to a traditional 401(k). Estimate my federal tax.
- What is the Florida sales tax rate? (not in the guide; the agent should say so)

## Troubleshooting

- **`Vector DB not found`**: run `python vector_db.py --reset` first, with the same `CHROMA_DIR` as the server.
- **Client cannot connect**: make sure the server is running and the URL ends with `/mcp`.
- **Model not found error from Anthropic**: set `ANTHROPIC_CHAT_MODEL_ID` to a model your key can access.
- **Semantic Kernel import or signature errors**: its agent and vector store APIs change between releases; check your installed version of `semantic-kernel`.
- **Garbled table text in some chunks**: PDF table extraction is basic; switching to `pdfplumber.extract_tables()` would improve it.

## Security notes

The MCP server has no authentication. Keep `MCP_HOST=127.0.0.1` unless you are on a trusted network; if you bind to `0.0.0.0`, put it behind authentication or a reverse proxy.
