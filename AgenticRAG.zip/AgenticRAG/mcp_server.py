"""
MCP server exposing the US tax knowledge base and a tax calculator.

Tools
  - search_tax_docs        : semantic search over the ChromaDB collection
  - get_standard_deduction : 2025 standard deduction by filing status
  - calculate_federal_tax  : 2025 federal income tax from taxable income

Runs as a standalone HTTP server (streamable-http). Start it separately:
    python mcp_server.py
The client connects to http://<host>:<port>/mcp  (default http://127.0.0.1:8000/mcp)
"""
import json
import logging
import os
import sys

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from vector_db import COLLECTION_NAME, get_collection

load_dotenv()
logging.basicConfig(stream=sys.stderr, level=logging.INFO)
log = logging.getLogger("tax-mcp")

# --- Semantic Kernel Chroma collection (same model/schema as vector_db.py) ---
_collection = get_collection()
_ready = False


async def _get_collection():
    """Lazily open the collection on first use (inside the server's event loop)."""
    global _ready
    if not _ready:
        await _collection.__aenter__()
        if not await _collection.collection_exists():
            raise RuntimeError("Vector DB not found. Run `python vector_db.py --reset` first.")
        _ready = True
        log.info("Opened SK Chroma collection '%s'", COLLECTION_NAME)
    return _collection


# --- 2025 tax data (illustrative; matches the sample PDF) ---
STANDARD_DEDUCTION = {"single": 15_750, "mfj": 31_500, "mfs": 15_750, "hoh": 23_625}
BRACKETS = {
    "single": [(11_925, .10), (48_475, .12), (103_350, .22), (197_300, .24), (250_525, .32), (626_350, .35), (float("inf"), .37)],
    "mfj":    [(23_850, .10), (96_950, .12), (206_700, .22), (394_600, .24), (501_050, .32), (751_600, .35), (float("inf"), .37)],
    "hoh":    [(17_000, .10), (64_850, .12), (103_350, .22), (197_300, .24), (250_500, .32), (626_350, .35), (float("inf"), .37)],
}
BRACKETS["mfs"] = BRACKETS["single"][:-2] + [(375_800, .35), (float("inf"), .37)]

MCP_HOST = os.getenv("MCP_HOST", "127.0.0.1")
MCP_PORT = int(os.getenv("MCP_PORT", "8000"))

mcp = FastMCP("us-tax-assistant", host=MCP_HOST, port=MCP_PORT)


def _norm_status(status: str) -> str:
    s = status.strip().lower().replace(" ", "")
    aliases = {"marriedfilingjointly": "mfj", "married": "mfj", "headofhousehold": "hoh",
               "marriedfilingseparately": "mfs"}
    s = aliases.get(s, s)
    if s not in STANDARD_DEDUCTION:
        raise ValueError(f"Unknown filing status '{status}'. Use one of: single, mfj, mfs, hoh")
    return s


@mcp.tool()
async def search_tax_docs(query: str, top_k: int = 4) -> str:
    """Semantic search over the US federal income tax guide (tax year 2025).
    Use this for questions about brackets, deductions, credits, capital gains,
    retirement accounts, self-employment tax, deadlines, penalties, and definitions.
    Returns the most relevant passages with section, page, and similarity score."""
    top_k = max(1, min(int(top_k), 10))
    collection = await _get_collection()
    search = await collection.search(values=query, top=top_k)
    results = [
        {
            "section": r.record.section,
            "page": r.record.page,
            "similarity": round(1 - r.score, 3),   # cosine distance -> similarity
            "text": r.record.text,
        }
        async for r in search.results
    ]
    return json.dumps(results, indent=2)


@mcp.tool()
def get_standard_deduction(filing_status: str) -> str:
    """Return the 2025 standard deduction.
    filing_status: single, mfj (married filing jointly), mfs (married filing separately), or hoh (head of household)."""
    fs = _norm_status(filing_status)
    return json.dumps({"filing_status": fs, "standard_deduction_2025": STANDARD_DEDUCTION[fs]})


@mcp.tool()
def calculate_federal_tax(taxable_income: float, filing_status: str) -> str:
    """Calculate 2025 federal ordinary income tax from TAXABLE income (after deductions).
    Returns total tax, marginal rate, effective rate, and a per-bracket breakdown.
    filing_status: single, mfj (married filing jointly), mfs (married filing separately), or hoh (head of household)."""
    fs = _norm_status(filing_status)
    remaining, lower, tax, breakdown = max(0.0, float(taxable_income)), 0.0, 0.0, []
    marginal = 0.10
    for upper, rate in BRACKETS[fs]:
        if remaining <= 0:
            break
        amount = min(remaining, upper - lower)
        piece = amount * rate
        tax += piece
        marginal = rate
        breakdown.append({"rate": f"{int(rate * 100)}%", "taxed_amount": round(amount, 2), "tax": round(piece, 2)})
        remaining -= amount
        lower = upper
    income = max(0.0, float(taxable_income))
    return json.dumps({
        "filing_status": fs,
        "taxable_income": income,
        "total_tax": round(tax, 2),
        "marginal_rate": f"{int(marginal * 100)}%",
        "effective_rate": f"{(tax / income * 100) if income else 0:.2f}%",
        "breakdown": breakdown,
    }, indent=2)


if __name__ == "__main__":
    log.info("MCP server at http://%s:%d/mcp", MCP_HOST, MCP_PORT)
    mcp.run(transport="streamable-http")