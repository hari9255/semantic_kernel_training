"""Deterministic federal tax engine (v1: single tax year, simplified).

All numbers live here, NOT in the LLM. Parameters are versioned by tax year.
VERIFY every figure against the IRS before using for anything real
(Rev. Proc. for the year, Form 1040 instructions, Schedule 8812 instructions).
"""
from __future__ import annotations

import math
from typing import Any

FILING_STATUSES = ("single", "mfj", "mfs", "hoh")

INF = float("inf")
# Bracket tuples are (upper_bound_of_bracket, rate).
PARAMS: dict[int, dict[str, Any]] = {
    2025: {
        "standard_deduction": {"single": 15750, "mfs": 15750, "mfj": 31500, "hoh": 23625},
        "brackets": {
            "single": [(11925, .10), (48475, .12), (103350, .22), (197300, .24), (250525, .32), (626350, .35), (INF, .37)],
            "mfs":    [(11925, .10), (48475, .12), (103350, .22), (197300, .24), (250525, .32), (375800, .35), (INF, .37)],
            "mfj":    [(23850, .10), (96950, .12), (206700, .22), (394600, .24), (501050, .32), (751600, .35), (INF, .37)],
            "hoh":    [(17000, .10), (64850, .12), (103350, .22), (197300, .24), (250500, .32), (626350, .35), (INF, .37)],
        },
        "child_tax_credit": {
            "per_child": 2200,
            "refundable_max_per_child": 1700,
            "phaseout_start": {"single": 200000, "mfs": 200000, "hoh": 200000, "mfj": 400000},
            "phaseout_rate_per_1000": 50,
            "refundable_earned_income_floor": 2500,
            "refundable_earned_income_rate": 0.15,
        },
        "social_security_wage_base": 176100,
        "sources": ["Rev. Proc. 2024-40 (as amended for 2025 legislation)", "Form 1040 Instructions", "Schedule 8812 Instructions"],
    },
    # Tax year 2024 (needed because most IRS notices concern prior years). VERIFY against Rev. Proc. 2023-34.
    2024: {
        "standard_deduction": {"single": 14600, "mfs": 14600, "mfj": 29200, "hoh": 21900},
        "brackets": {
            "single": [(11600, .10), (47150, .12), (100525, .22), (191950, .24), (243725, .32), (609350, .35), (INF, .37)],
            "mfs":    [(11600, .10), (47150, .12), (100525, .22), (191950, .24), (243725, .32), (365600, .35), (INF, .37)],
            "mfj":    [(23200, .10), (94300, .12), (201050, .22), (383900, .24), (487450, .32), (731200, .35), (INF, .37)],
            "hoh":    [(16550, .10), (63100, .12), (100500, .22), (191950, .24), (243700, .32), (609350, .35), (INF, .37)],
        },
        "child_tax_credit": {
            "per_child": 2000,
            "refundable_max_per_child": 1700,
            "phaseout_start": {"single": 200000, "mfs": 200000, "hoh": 200000, "mfj": 400000},
            "phaseout_rate_per_1000": 50,
            "refundable_earned_income_floor": 2500,
            "refundable_earned_income_rate": 0.15,
        },
        "social_security_wage_base": 168600,
        "sources": ["Rev. Proc. 2023-34", "Form 1040 Instructions (2024)"],
    },
}


def get_tax_parameters(year: int, filing_status: str) -> dict[str, Any]:
    if year not in PARAMS:
        raise ValueError(f"Tax year {year} not supported. Supported: {sorted(PARAMS)}")
    if filing_status not in FILING_STATUSES:
        raise ValueError(f"filing_status must be one of {FILING_STATUSES}")
    p = PARAMS[year]
    return {
        "tax_year": year,
        "filing_status": filing_status,
        "standard_deduction": p["standard_deduction"][filing_status],
        "brackets": [{"up_to": (None if b == INF else b), "rate": r} for b, r in p["brackets"][filing_status]],
        "child_tax_credit": {**p["child_tax_credit"], "phaseout_start": p["child_tax_credit"]["phaseout_start"][filing_status]},
        "sources": p["sources"],
    }


def _bracket_tax(taxable: float, brackets: list[tuple[float, float]]) -> tuple[float, list[dict]]:
    tax, lower, detail = 0.0, 0.0, []
    for upper, rate in brackets:
        if taxable <= lower:
            break
        slice_ = min(taxable, upper) - lower
        amt = slice_ * rate
        tax += amt
        detail.append({"rate": rate, "income_in_bracket": round(slice_, 2), "tax": round(amt, 2)})
        lower = upper
    return tax, detail


def calculate_federal_tax(
    tax_year: int,
    filing_status: str,
    wages: float = 0.0,
    taxable_interest: float = 0.0,
    ordinary_dividends: float = 0.0,
    qualified_dividends: float = 0.0,
    other_income: float = 0.0,
    adjustments: float = 0.0,
    itemized_deductions: float | None = None,
    qualifying_children: int = 0,
    federal_withholding: float = 0.0,
) -> dict[str, Any]:
    """Return a Form 1040-style estimate with line-by-line reasoning."""
    params = get_tax_parameters(tax_year, filing_status)
    p = PARAMS[tax_year]
    warnings: list[str] = []

    for name, v in dict(wages=wages, taxable_interest=taxable_interest, ordinary_dividends=ordinary_dividends,
                        other_income=other_income, adjustments=adjustments, federal_withholding=federal_withholding).items():
        if v < 0:
            raise ValueError(f"{name} cannot be negative")

    total_income = wages + taxable_interest + ordinary_dividends + other_income      # 1040 line 9
    agi = max(0.0, total_income - adjustments)                                       # line 11
    std = params["standard_deduction"]
    use_itemized = itemized_deductions is not None and itemized_deductions > std
    deduction = itemized_deductions if use_itemized else std                         # line 12
    taxable_income = max(0.0, agi - deduction)                                       # line 15
    tax, bracket_detail = _bracket_tax(taxable_income, p["brackets"][filing_status])  # line 16

    # Child tax credit (simplified Schedule 8812)
    ctc = p["child_tax_credit"]
    gross_ctc = qualifying_children * ctc["per_child"]
    excess = max(0.0, agi - ctc["phaseout_start"][filing_status])
    reduction = math.ceil(excess / 1000) * ctc["phaseout_rate_per_1000"] if excess else 0
    ctc_after_phaseout = max(0.0, gross_ctc - reduction)
    nonrefundable = min(ctc_after_phaseout, tax)
    leftover = ctc_after_phaseout - nonrefundable
    earned_cap = max(0.0, wages - ctc["refundable_earned_income_floor"]) * ctc["refundable_earned_income_rate"]
    refundable = min(leftover, qualifying_children * ctc["refundable_max_per_child"], earned_cap)

    total_tax = max(0.0, tax - nonrefundable)
    total_payments = federal_withholding + refundable
    net = total_payments - total_tax

    if qualified_dividends:
        warnings.append("Qualified dividends were taxed at ordinary rates in v1; the preferential 0/15/20% "
                        "rates (Qualified Dividends and Capital Gain Tax Worksheet) are not applied, so tax may be overstated.")
    if itemized_deductions is not None and not use_itemized:
        warnings.append("Itemized deductions were lower than the standard deduction, so the standard deduction was used.")
    if filing_status == "mfs":
        warnings.append("Married filing separately has special rules (e.g. itemizing consistency, credit limits) not modeled in v1.")
    if agi > 200000:
        warnings.append("High-income items (NIIT, Additional Medicare Tax) are not modeled in v1.")

    r = lambda x: round(float(x), 2)
    return {
        "tax_year": tax_year,
        "filing_status": filing_status,
        "lines": {
            "total_income_line9": r(total_income),
            "adjustments_schedule1": r(adjustments),
            "agi_line11": r(agi),
            "standard_deduction": r(std),
            "itemized_deductions": r(itemized_deductions) if itemized_deductions is not None else None,
            "deduction_used_line12": r(deduction),
            "deduction_type": "itemized" if use_itemized else "standard",
            "taxable_income_line15": r(taxable_income),
            "tax_before_credits_line16": r(tax),
            "child_tax_credit_nonrefundable": r(nonrefundable),
            "total_tax_line24": r(total_tax),
            "federal_withholding_line25": r(federal_withholding),
            "refundable_child_tax_credit": r(refundable),
            "total_payments_line33": r(total_payments),
        },
        "bracket_detail": bracket_detail,
        "result": {"type": "refund" if net >= 0 else "balance_due", "amount": r(abs(net))},
        "effective_rate_on_agi": r(total_tax / agi * 100) if agi else 0.0,
        "warnings": warnings,
        "sources": params["sources"],
        "disclaimer": "Estimate for educational purposes; not professional tax advice.",
    }


# ---------------------------------------------------------------- validation

_REQUIRED = {
    "W-2": ["employer_name", "wages", "federal_withholding"],
    "1099-INT": ["payer_name", "interest_income"],
    "1099-DIV": ["payer_name", "ordinary_dividends"],
}


def validate_form_fields(form_type: str, data: dict[str, Any], tax_year: int = 2025) -> dict[str, Any]:
    """Schema + sanity checks. Returns errors (must fix) and warnings (review)."""
    errors, warnings = [], []
    ft = form_type.upper().replace(" ", "")
    ft = {"W2": "W-2", "1099INT": "1099-INT", "1099DIV": "1099-DIV"}.get(ft, ft)
    if ft not in _REQUIRED:
        return {"valid": False, "errors": [f"Unsupported form type '{form_type}'. Supported: {list(_REQUIRED)}"],
                "warnings": [], "needs_human_review": True}

    for f in _REQUIRED[ft]:
        if data.get(f) in (None, ""):
            errors.append(f"Missing required field: {f}")
    for k, v in data.items():
        if isinstance(v, (int, float)) and v < 0:
            errors.append(f"{k} must not be negative")

    if ft == "W-2":
        wages, wh = data.get("wages") or 0, data.get("federal_withholding") or 0
        if wh > wages:
            errors.append("Federal withholding (Box 2) exceeds wages (Box 1): likely an extraction error.")
        elif wages and wh / wages > 0.40:
            warnings.append("Withholding is over 40% of wages; please double-check Box 1 and Box 2.")
        base = PARAMS.get(tax_year, {}).get("social_security_wage_base", 176100)
        ss_w, ss_t = data.get("social_security_wages"), data.get("social_security_tax")
        if ss_w is not None and ss_w > base:
            errors.append(f"Social Security wages (Box 3) exceed the {tax_year} wage base of ${base:,}.")
        if ss_w and ss_t is not None and abs(ss_t - ss_w * 0.062) > max(5, ss_w * 0.002):
            warnings.append("Box 4 is not ~6.2% of Box 3.")
        m_w, m_t = data.get("medicare_wages"), data.get("medicare_tax")
        if m_w and m_t is not None and abs(m_t - m_w * 0.0145) > max(5, m_w * 0.002):
            warnings.append("Box 6 is not ~1.45% of Box 5 (Additional Medicare Tax may apply above $200k).")
        if wages and ss_w and wages > ss_w * 1.001 + 1:
            warnings.append("Box 1 wages exceed Box 3 wages; confirm pre-tax deductions or box mix-up.")
    if ft == "1099-DIV":
        od, qd = data.get("ordinary_dividends") or 0, data.get("qualified_dividends") or 0
        if qd > od:
            errors.append("Qualified dividends (1b) cannot exceed ordinary dividends (1a).")
    return {"valid": not errors, "errors": errors, "warnings": warnings, "needs_human_review": bool(errors)}
