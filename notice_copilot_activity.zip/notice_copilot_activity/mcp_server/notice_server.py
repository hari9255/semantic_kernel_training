"""Notice Tools MCP server (stdio). Run standalone: python -m mcp_server.notice_server"""
import json

from mcp.server.fastmcp import FastMCP

from . import notice_engine as ne

mcp = FastMCP("notice-tools")


@mcp.tool()
def lookup_notice_type(code: str) -> str:
    """Look up an IRS notice code (e.g. CP2000, CP14). Returns its meaning, what the IRS wants,
    the standard response window in days (null if none), the usual options, and whether it is serious."""
    return json.dumps(ne.lookup_notice_type(code))


@mcp.tool()
def calculate_deadline(notice_date: str, response_days: int, as_of: str = "") -> str:
    """Compute a response due date. notice_date and as_of are YYYY-MM-DD (as_of defaults to today).
    Rolls weekends and US federal holidays forward and returns days remaining and an urgency status."""
    try:
        return json.dumps(ne.calculate_deadline(notice_date, response_days, as_of or None))
    except ValueError as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def recalculate_tax_difference(
    tax_year: int,
    filing_status: str,
    wages: float = 0,
    taxable_interest: float = 0,
    ordinary_dividends: float = 0,
    other_income: float = 0,
    adjustments: float = 0,
    itemized_deductions: float = 0,
    qualifying_children: int = 0,
    additional_income: float = 0,
    irs_proposed_tax: float = -1,
) -> str:
    """Recompute the income-tax effect of adding `additional_income` (income the IRS says is missing and that is
    NOT already on the return) to the return as filed. Pass the AS-FILED figures for everything else.
    Pass irs_proposed_tax (the notice's proposed tax increase) to get a comparison; -1 means not provided.
    itemized_deductions 0 means standard deduction. Income tax only; no self-employment tax or interest."""
    try:
        return json.dumps(ne.recalculate_tax_difference(
            tax_year, filing_status, wages, taxable_interest, ordinary_dividends, other_income, adjustments,
            itemized_deductions or None, qualifying_children, additional_income,
            None if irs_proposed_tax < 0 else irs_proposed_tax))
    except ValueError as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def search_irs_guidance(query: str) -> str:
    """Search IRS guidance snippets (notices, penalties, appeals, payment plans). Returns source names and URLs; cite them."""
    return json.dumps(ne.search_guidance(query))


if __name__ == "__main__":
    mcp.run()
