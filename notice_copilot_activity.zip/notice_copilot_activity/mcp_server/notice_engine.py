"""Deterministic notice logic: notice-type knowledge, deadline math, tax recalculation, guidance search.

Everything numeric or date-based lives here, not in the LLM.
VERIFY notice facts (response windows, rights) against irs.gov before relying on them.
"""
from __future__ import annotations

import re
from datetime import date, timedelta
from typing import Any

from . import tax_engine

# --------------------------------------------------------------------------- notice knowledge

NOTICE_TYPES: dict[str, dict[str, Any]] = {
    "CP2000": {
        "title": "Proposed changes to your return (income on your return does not match third-party reports)",
        "summary": "The IRS compared your return with income reported by employers, banks and other payers and found "
                   "a mismatch. It proposes to change your tax. This is NOT a bill and NOT an audit.",
        "irs_wants": "Review the proposal and respond by the date on the notice: agree, partly agree, or disagree.",
        "response_days": 30,
        "response_basis": "About 30 days from the notice date. The date printed on the notice controls.",
        "options": [
            "Agree: sign and return the response form, and pay or ask about a payment plan.",
            "Partly agree: say which items you accept and send proof for the rest.",
            "Disagree: send a signed statement with supporting documents.",
            "Need more time: ask in writing BEFORE the deadline.",
        ],
        "verifiable": True,
        "serious": False,
        "source": {"name": "Understanding your CP2000 notice", "url": "https://www.irs.gov/individuals/understanding-your-cp2000-notice"},
    },
    "CP14": {
        "title": "Balance due notice",
        "summary": "You have an unpaid tax balance for the year shown, plus penalties and interest that keep growing until it is paid.",
        "irs_wants": "Pay the balance by the date shown, or contact the IRS if you think it is wrong.",
        "response_days": 21,
        "response_basis": "Payment is normally due about 21 days from the notice date. The date printed on the notice controls.",
        "options": [
            "Pay in full (IRS Direct Pay, bank account, or card).",
            "Request a payment plan if you cannot pay in full.",
            "Dispute it: check that your payments were credited, then contact the IRS with proof.",
        ],
        "verifiable": False,
        "serious": False,
        "source": {"name": "IRS notices and letters", "url": "https://www.irs.gov/notices"},
    },
    "CP11": {
        "title": "We changed your return (math or clerical error) - balance due",
        "summary": "The IRS corrected what it says is a math or clerical error on your return, and the correction leaves you owing money.",
        "irs_wants": "Pay the balance, or dispute the change in writing within the allowed window.",
        "response_days": 60,
        "response_basis": "Generally 60 days to ask in writing for a math-error change to be reversed.",
        "options": ["Agree and pay.", "Disagree in writing within the window and explain with documents.", "Request a payment plan if needed."],
        "verifiable": False,
        "serious": False,
        "source": {"name": "IRS notices and letters", "url": "https://www.irs.gov/notices"},
    },
    "CP12": {
        "title": "We changed your return (math or clerical error) - refund adjusted",
        "summary": "The IRS corrected a math or clerical error, and your refund amount changed.",
        "irs_wants": "Nothing required if you agree. Respond in writing if you disagree.",
        "response_days": 60,
        "response_basis": "Generally 60 days to dispute a math-error change.",
        "options": ["Agree: no action needed.", "Disagree in writing within the window with supporting documents."],
        "verifiable": False,
        "serious": False,
        "source": {"name": "IRS notices and letters", "url": "https://www.irs.gov/notices"},
    },
    "CP501": {
        "title": "Reminder: you have a balance due",
        "summary": "A first reminder that a tax balance is still unpaid.",
        "irs_wants": "Pay promptly to limit further interest and penalties.",
        "response_days": None,
        "response_basis": "No fixed response window; pay as soon as you can.",
        "options": ["Pay in full.", "Request a payment plan.", "Contact the IRS if you already paid or disagree."],
        "verifiable": False,
        "serious": False,
        "source": {"name": "IRS notices and letters", "url": "https://www.irs.gov/notices"},
    },
    "CP503": {
        "title": "Second reminder: you have a balance due",
        "summary": "A second reminder that a tax balance is still unpaid. Collection steps are getting closer.",
        "irs_wants": "Pay promptly.",
        "response_days": None,
        "response_basis": "No fixed response window; act quickly.",
        "options": ["Pay in full.", "Request a payment plan.", "Contact the IRS if you already paid or disagree."],
        "verifiable": False,
        "serious": False,
        "source": {"name": "IRS notices and letters", "url": "https://www.irs.gov/notices"},
    },
    "CP504": {
        "title": "Notice of intent to levy (seize) property or a refund",
        "summary": "The IRS says it intends to collect an unpaid balance by seizing property or a refund. This is a serious collection notice.",
        "irs_wants": "Pay or contact the IRS immediately.",
        "response_days": 30,
        "response_basis": "Generally 30 days. The date printed on the notice controls.",
        "options": ["Pay in full.", "Arrange a payment plan right away.",
                    "Get help from a tax professional or the Taxpayer Advocate Service."],
        "verifiable": False,
        "serious": True,
        "source": {"name": "IRS notices and letters", "url": "https://www.irs.gov/notices"},
    },
}


def normalize_code(code: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", (code or "").upper())


def get_notice_type(code: str) -> dict[str, Any] | None:
    c = normalize_code(code)
    entry = NOTICE_TYPES.get(c)
    return {"code": c, **entry} if entry else None


def lookup_notice_type(code: str) -> dict[str, Any]:
    found = get_notice_type(code)
    if found:
        return found
    return {"error": f"Unknown or unsupported notice code '{code}'.", "supported": sorted(NOTICE_TYPES),
            "needs_human_review": True}


# --------------------------------------------------------------------------- deadlines

def _nth_weekday(y: int, m: int, weekday: int, n: int) -> date:
    first = date(y, m, 1)
    return first + timedelta(days=(weekday - first.weekday()) % 7 + 7 * (n - 1))


def _last_weekday(y: int, m: int, weekday: int) -> date:
    nxt = date(y + (m == 12), m % 12 + 1, 1)
    last = nxt - timedelta(days=1)
    return last - timedelta(days=(last.weekday() - weekday) % 7)


def _observed(d: date) -> date:
    return d - timedelta(days=1) if d.weekday() == 5 else d + timedelta(days=1) if d.weekday() == 6 else d


def federal_holidays(year: int) -> dict[date, str]:
    """US federal holidays (observed dates). Note: DC Emancipation Day (Apr 16) is not included."""
    fixed = {(1, 1): "New Year's Day", (6, 19): "Juneteenth", (7, 4): "Independence Day",
             (11, 11): "Veterans Day", (12, 25): "Christmas Day"}
    out = {_observed(date(year, m, d)): name for (m, d), name in fixed.items()}
    out[_nth_weekday(year, 1, 0, 3)] = "Martin Luther King Jr. Day"
    out[_nth_weekday(year, 2, 0, 3)] = "Washington's Birthday"
    out[_last_weekday(year, 5, 0)] = "Memorial Day"
    out[_nth_weekday(year, 9, 0, 1)] = "Labor Day"
    out[_nth_weekday(year, 10, 0, 2)] = "Columbus Day"
    out[_nth_weekday(year, 11, 3, 4)] = "Thanksgiving Day"
    return out


def _holiday_name(d: date) -> str | None:
    return federal_holidays(d.year).get(d) or federal_holidays(d.year + 1).get(d)


def is_business_day(d: date) -> bool:
    return d.weekday() < 5 and _holiday_name(d) is None


def calculate_deadline(notice_date: str, response_days: int, as_of: str | None = None) -> dict[str, Any]:
    start = date.fromisoformat(notice_date)
    today = date.fromisoformat(as_of) if as_of else date.today()
    if response_days < 0 or response_days > 400:
        raise ValueError("response_days must be between 0 and 400")
    raw = start + timedelta(days=response_days)
    due, reason = raw, None
    while not is_business_day(due):
        reason = reason or (_holiday_name(due) or due.strftime("%A"))
        due += timedelta(days=1)
    remaining = (due - today).days
    status = ("overdue" if remaining < 0 else "due_today" if remaining == 0 else
              "urgent" if remaining <= 7 else "soon" if remaining <= 14 else "ok")
    return {
        "notice_date": start.isoformat(), "response_days": response_days,
        "raw_due_date": raw.isoformat(), "due_date": due.isoformat(), "weekday": due.strftime("%A"),
        "rolled_forward": due != raw, "roll_reason": reason,
        "as_of": today.isoformat(), "days_remaining": remaining, "status": status,
        "note": "The date printed on the notice is authoritative; this is a cross-check. "
                "Do not rely on a weekend/holiday roll-forward for IRS notice response dates; "
                "treat the earlier date as safest.",
    }


# --------------------------------------------------------------------------- recalculation

def recalculate_tax_difference(
    tax_year: int, filing_status: str, wages: float = 0.0, taxable_interest: float = 0.0,
    ordinary_dividends: float = 0.0, other_income: float = 0.0, adjustments: float = 0.0,
    itemized_deductions: float | None = None, qualifying_children: int = 0,
    additional_income: float = 0.0, irs_proposed_tax: float | None = None, penalty_rate: float = 0.20,
) -> dict[str, Any]:
    """Tax effect of adding `additional_income` to the return AS FILED. Income tax only."""
    if additional_income < 0:
        raise ValueError("additional_income cannot be negative")
    common = dict(tax_year=tax_year, filing_status=filing_status, wages=wages, taxable_interest=taxable_interest,
                  ordinary_dividends=ordinary_dividends, adjustments=adjustments,
                  itemized_deductions=itemized_deductions or None, qualifying_children=qualifying_children)
    before = tax_engine.calculate_federal_tax(other_income=other_income, **common)
    after = tax_engine.calculate_federal_tax(other_income=other_income + additional_income, **common)
    inc = round(after["lines"]["total_tax_line24"] - before["lines"]["total_tax_line24"], 2)
    out: dict[str, Any] = {
        "tax_year": tax_year, "additional_income_tested": round(additional_income, 2),
        "total_tax_as_filed": before["lines"]["total_tax_line24"],
        "total_tax_revised": after["lines"]["total_tax_line24"],
        "tax_increase": inc,
        "estimated_accuracy_penalty": round(inc * penalty_rate, 2),
        "estimated_total_before_interest": round(inc * (1 + penalty_rate), 2),
        "warnings": [
            "Income tax only. Self-employment tax (Schedule SE) may also apply to 1099-NEC income and is not modeled.",
            "Interest is not calculated; use the figure on the notice.",
            "The accuracy-related penalty can be removed if you show reasonable cause.",
        ],
    }
    if irs_proposed_tax is not None:
        out["irs_proposed_tax"] = round(irs_proposed_tax, 2)
        out["difference_vs_irs"] = round(inc - irs_proposed_tax, 2)
        out["matches_irs_within_5_dollars"] = abs(inc - irs_proposed_tax) <= 5
    return out


# --------------------------------------------------------------------------- guidance search

DOCS = [
    {"source": "Understanding your CP2000 notice", "url": "https://www.irs.gov/individuals/understanding-your-cp2000-notice",
     "text": "A CP2000 notice says income or payment information the IRS has does not match your return. It is not a bill and not an audit. Respond by the date on the notice by agreeing, partly agreeing or disagreeing, and send documents that support your position."},
    {"source": "Publication 5 - Your Appeal Rights", "url": "https://www.irs.gov/publications/p5",
     "text": "If you disagree with a proposed IRS change you may ask for an independent review by the IRS Independent Office of Appeals. Instructions are in the notice or a follow-up letter."},
    {"source": "Publication 1 - Your Rights as a Taxpayer", "url": "https://www.irs.gov/publications/p1",
     "text": "Taxpayers have the right to challenge the IRS position and be heard, to appeal an IRS decision independently, to pay no more than the correct amount of tax, and to retain representation."},
    {"source": "About Form 9465 - Installment Agreement Request", "url": "https://www.irs.gov/forms-pubs/about-form-9465",
     "text": "If you cannot pay in full you may request a monthly payment plan with Form 9465 or the online payment agreement tool. Interest and penalties continue to accrue until the balance is paid."},
    {"source": "IRS Direct Pay", "url": "https://www.irs.gov/payments/direct-pay",
     "text": "Direct Pay lets you pay tax from a checking or savings account at no charge and shows a confirmation."},
    {"source": "Accuracy-related penalty", "url": "https://www.irs.gov/payments/accuracy-related-penalty",
     "text": "The accuracy-related penalty is generally 20 percent of the underpayment caused by negligence or a substantial understatement of income tax. It may be removed if you show reasonable cause and good faith."},
    {"source": "Interest on unpaid tax", "url": "https://www.irs.gov/payments/interest",
     "text": "Interest accrues on unpaid tax from the original due date of the return until the balance is paid, is compounded daily, and the rate is set every quarter."},
    {"source": "Tax Topic 554 - Self-employment tax", "url": "https://www.irs.gov/taxtopics/tc554",
     "text": "Nonemployee compensation reported on Form 1099-NEC is generally self-employment income reported on Schedule C and may be subject to self-employment tax calculated on Schedule SE."},
    {"source": "First-time penalty abatement", "url": "https://www.irs.gov/payments/penalty-relief-due-to-first-time-abate-or-other-administrative-waiver",
     "text": "Taxpayers with a clean compliance history for the prior three years may qualify for first-time penalty abatement of failure-to-file, failure-to-pay or failure-to-deposit penalties."},
    {"source": "Taxpayer Advocate Service", "url": "https://www.taxpayeradvocate.irs.gov",
     "text": "The Taxpayer Advocate Service is an independent organization within the IRS that helps taxpayers whose problems are not being resolved through normal channels, and it is free."},
    {"source": "IRS notices and letters", "url": "https://www.irs.gov/notices",
     "text": "Notices explain changes to your account or return, balances due, and what to do next. Keep the notice, respond by the stated date, and keep copies of everything you send. If you disagree with a math-error change you generally have 60 days to ask in writing for it to be reversed."},
]

_tok = lambda s: set(re.findall(r"[a-z0-9\-]+", s.lower()))


def search_guidance(query: str, k: int = 3) -> list[dict]:
    q = _tok(query)
    scored = [(len(q & _tok(d["text"] + " " + d["source"])), d) for d in DOCS]
    scored = [x for x in scored if x[0]]
    scored.sort(key=lambda x: -x[0])
    return [d for _, d in scored[:k]]
