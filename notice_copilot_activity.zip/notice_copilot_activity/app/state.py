"""Short-term memory: one NoticeCase shared by all agents during a session."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class NoticeCase:
    today: str                                   # ISO date; injected so runs are reproducible
    notice_file: str | None = None
    notice_code: str | None = None
    tax_year: int | None = None
    notice_date: str | None = None
    printed_response_date: str | None = None
    taxpayer_name: str | None = None
    total_amount_due: float = 0.0
    proposed_tax_increase: float = 0.0
    proposed_penalty: float = 0.0
    proposed_interest: float = 0.0
    income_items: list[dict[str, Any]] = field(default_factory=list)   # payer, income_type, irs_amount, return_amount
    confirmed: bool = False

    deadline: str | None = None
    deadline_source: str | None = None
    explanation: str = ""

    return_summary: dict[str, Any] | None = None
    verification: dict[str, Any] | None = None

    user_decision: str | None = None             # agree | disagree | partial | unsure
    user_note: str = ""
    response_kind: str | None = None
    response_text: str = ""

    human_review_flags: list[str] = field(default_factory=list)

    def snapshot(self) -> dict[str, Any]:
        d = asdict(self)
        for k in ("explanation", "response_text"):
            d.pop(k, None)
        return d
