"""PII masking. SSNs/ITINs must never reach the LLM, tool args, or logs."""
import logging
import re

_SSN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
REDACTED = "[SSN-REDACTED]"


def mask_pii(text: str) -> str:
    return _SSN.sub(REDACTED, text) if isinstance(text, str) else text


class PiiLogFilter(logging.Filter):
    """Attach to handlers/loggers so SSNs can't leak through log lines."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = mask_pii(str(record.msg))
        if record.args:
            record.args = tuple(mask_pii(a) if isinstance(a, str) else a for a in record.args)
        return True


async def pii_function_filter(context, next):
    """Semantic Kernel function-invocation filter: scrub args going in and results coming out."""
    from semantic_kernel.functions import FunctionResult

    for k, v in list(context.arguments.items()):
        if isinstance(v, str):
            context.arguments[k] = mask_pii(v)
    await next(context)
    res = context.result
    if res is not None and isinstance(res.value, str):
        context.result = FunctionResult(function=res.function, value=mask_pii(res.value), metadata=res.metadata)
