"""Agent factory: four specialised Semantic Kernel ChatCompletionAgents on Anthropic Claude."""
from __future__ import annotations

import os
from pathlib import Path

from semantic_kernel import Kernel
from semantic_kernel.agents import ChatCompletionAgent
from semantic_kernel.connectors.ai import FunctionChoiceBehavior
from semantic_kernel.connectors.ai.anthropic import AnthropicChatCompletion, AnthropicChatPromptExecutionSettings
from semantic_kernel.filters import FilterTypes
from semantic_kernel.functions import KernelArguments

from .pii import pii_function_filter
from .plugins import (CaseReaderPlugin, DocumentPlugin, ExplainPlugin, IntakePlugin, ResponsePlugin, VerifyPlugin)
from .state import NoticeCase

MCP_PLUGIN_NAME = "NoticeTools"
MAX_TOOL_ROUNDS = 12          # SK default is 5, too low for multi-step agents; after the cap SK silently drops the tools
DISCLAIMER = "This is general information to help you understand your notice. It is not legal or tax advice."

_COMMON = """You are one step in an assistant that helps individual US taxpayers understand IRS notices
(v1 scope: CP2000, CP14, CP11, CP12, CP501, CP503, CP504). Today's date is {today}.
Rules: never compute dates or tax amounts yourself, use the tools. Never ask for or repeat Social Security numbers.
Do not invent facts, amounts, or legal arguments that are not in the documents or tool results.
Never tell the taxpayer to ignore a notice. If something is unsupported, unreadable, or serious, say so plainly,
call flag_for_human_review where you have it, and recommend a tax professional. Use plain, short sentences."""

CLASSIFIER = _COMMON + """
ROLE: Classifier Agent. Call list_documents, then read_document on files until you find the IRS notice
(it has a notice code such as CP2000 near the top, a notice date and a tax year). Other files, such as a return
summary, are NOT the notice. Extract the facts and call record_notice_facts exactly once: dates as YYYY-MM-DD,
amounts as plain numbers, income_items_json as a JSON array (payer, income_type, irs_amount, return_amount),
or [] if there is no income table. total_amount_due is the total the notice says is owed. printed_response_date
is the 'respond by' or 'pay by' date printed on the notice. If an extraction tool call returns ERROR, fix it and
retry. If the taxpayer gives a correction, call record_notice_facts again with the corrected values.
Finish with a compact table of what you recorded and ask the taxpayer to confirm."""

EXPLAINER = _COMMON + """
ROLE: Explainer Agent. Steps: get_case; lookup_notice_type with the notice code; search_irs_guidance once or twice
for the key topic (for example the notice number, penalty, or payment plan). Deadline: the date printed on the notice
is authoritative. If the lookup has response_days, also call calculate_deadline(notice_date, response_days, as_of=today)
as a cross-check and mention any mismatch. Then call set_deadline with the printed date (source 'printed on notice')
or, if none is printed, the calculated date (source 'calculated').
Write: What this is; What the IRS says (amounts exactly as recorded); What you must do and by when (state days left
and urgency); Your options; Sources (names from the search results). Reading level: grade 8."""

VERIFIER = _COMMON + """
ROLE: Verifier Agent (CP2000 only). Steps: get_case; list_documents; find the taxpayer's return summary (not the
notice) and read it; record_return_summary with the AS-FILED figures. For EACH income item on the notice decide whether
that income already appears on the return (match the payer and amount to the lines, including other income).
Sum the items NOT on the return into additional_income. Call recalculate_tax_difference with the as-filed figures,
additional_income, and irs_proposed_tax = the notice's proposed tax increase. Verdict: irs_correct if every item is
missing from the return and the recomputed increase matches the notice; irs_incorrect if every item is already on the
return; partially_correct for a mix or a mismatch; cannot_determine if the return summary is missing or unclear.
Call record_verification, then explain the finding in a few sentences. Mention that self-employment tax and interest
are not modeled. If the return summary is missing, say so and use cannot_determine."""

RESPONDER = _COMMON + """
ROLE: Response Agent. get_case first. You have the taxpayer's decision (agree, disagree, partial, unsure) and note in
the case and in the request. Draft the response and save it with save_response_draft(kind, text), then give a 3-line summary.
Kinds: agree + CP2000 -> agree_steps; agree + other notices -> payment_steps; disagree -> disagree_letter;
partial -> partial_letter; unsure -> info_checklist (what to gather, the options, and where to get free help,
for example the Taxpayer Advocate Service).
Letters: use placeholders such as [Your name], [Your address], [Date]; write 'SSN: [write by hand on your copy]'.
Include notice code, tax year, notice date, a clear statement of what is disputed, and an Enclosures checklist.
Base every claim ONLY on the verification result and the taxpayer's note. If the taxpayer disagrees but the verification
says irs_correct, do NOT invent grounds: say what the records show, and produce an info_checklist instead.
Always include: the response deadline, 'send a copy, keep the original, use trackable mail', and a note that
self-employment tax and interest may also apply where relevant. Do not promise outcomes."""


def build_agents(case: NoticeCase, docs_dir: Path, mcp_plugin, service=None) -> dict[str, ChatCompletionAgent]:
    service = service or AnthropicChatCompletion(
        ai_model_id=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5"), api_key=os.environ["ANTHROPIC_API_KEY"])
    docs, reader = DocumentPlugin(docs_dir), CaseReaderPlugin(case)

    def mk(name: str, instructions: str, plugins: list, mcp_tools: list[str]) -> ChatCompletionAgent:
        kernel = Kernel()
        kernel.add_filter(FilterTypes.FUNCTION_INVOCATION, pii_function_filter)
        included = [f"{p.__class__.__name__}-{n}" for p in plugins for n in _fn_names(p)]
        included += [f"{MCP_PLUGIN_NAME}-{t}" for t in mcp_tools]            # least-privilege tool exposure
        settings = AnthropicChatPromptExecutionSettings(
            max_tokens=2500,
            function_choice_behavior=FunctionChoiceBehavior.Auto(
                filters={"included_functions": included}, maximum_auto_invoke_attempts=MAX_TOOL_ROUNDS))
        return ChatCompletionAgent(
            name=name, instructions=instructions.replace("{today}", case.today), service=service, kernel=kernel,
            plugins=[*plugins, mcp_plugin], arguments=KernelArguments(settings=settings))

    return {
        "classifier": mk("ClassifierAgent", CLASSIFIER, [docs, IntakePlugin(case)], []),
        "explainer": mk("ExplainerAgent", EXPLAINER, [reader, ExplainPlugin(case)],
                        ["lookup_notice_type", "calculate_deadline", "search_irs_guidance"]),
        "verifier": mk("VerifierAgent", VERIFIER, [reader, docs, VerifyPlugin(case)], ["recalculate_tax_difference"]),
        "responder": mk("ResponseAgent", RESPONDER, [reader, ResponsePlugin(case)], ["search_irs_guidance"]),
    }


def _fn_names(plugin) -> list[str]:
    return [n for n in dir(plugin) if hasattr(getattr(plugin, n), "__kernel_function__")]
