"""Native Semantic Kernel plugins. Each agent only gets the plugins it needs (least privilege)."""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path
from typing import Annotated

import pdfplumber
from semantic_kernel.functions import kernel_function

from mcp_server import notice_engine
from .pii import mask_pii
from .state import NoticeCase

HIGH_AMOUNT = 5000.0
_FS = {"single", "mfj", "mfs", "hoh"}
VERDICTS = {"irs_correct", "irs_incorrect", "partially_correct", "cannot_determine", "not_applicable"}
RESPONSE_KINDS = {"payment_steps", "agree_steps", "disagree_letter", "partial_letter", "info_checklist"}


def _iso(s: str, label: str) -> str:
    try:
        return date.fromisoformat(s).isoformat()
    except ValueError:
        raise ValueError(f"{label} must be YYYY-MM-DD, got '{s}'")


class DocumentPlugin:
    """PDF access sandboxed to one folder. Text is PII-masked before the LLM sees it."""

    def __init__(self, root: Path):
        self.root = root.resolve()

    @kernel_function(description="List the PDF documents available to read.")
    def list_documents(self) -> str:
        return json.dumps(sorted(p.name for p in self.root.glob("*.pdf")))

    @kernel_function(description="Read the text of one PDF by file name. SSNs are redacted.")
    def read_document(self, file_name: Annotated[str, "File name from list_documents"]) -> str:
        path = (self.root / file_name).resolve()
        if path.parent != self.root or path.suffix.lower() != ".pdf" or not path.exists():
            return "ERROR: file not found in the documents folder."
        with pdfplumber.open(path) as pdf:
            text = "\n".join((pg.extract_text() or "") for pg in pdf.pages)
        return mask_pii(text) or "ERROR: no text could be extracted (scanned image? needs OCR / human review)."


class CaseReaderPlugin:
    """Read-only view of the case, for every agent."""

    def __init__(self, case: NoticeCase):
        self.c = case

    @kernel_function(description="Get everything known about the notice case so far (facts, deadline, verification, decision).")
    def get_case(self) -> str:
        return json.dumps(self.c.snapshot(), default=str)


class IntakePlugin:
    """Classifier agent writes the extracted notice facts here. Calling it again overwrites (used for corrections)."""

    def __init__(self, case: NoticeCase):
        self.c = case

    @kernel_function(description=(
        "Record facts extracted from the IRS notice. Dates must be YYYY-MM-DD and amounts plain numbers. "
        "income_items_json is a JSON array of objects with keys payer, income_type, irs_amount, return_amount "
        "(use [] when the notice has no income table)."))
    def record_notice_facts(
        self, notice_file: str, notice_code: str, tax_year: int, notice_date: str,
        printed_response_date: str = "", taxpayer_name: str = "", total_amount_due: float = 0.0,
        proposed_tax_increase: float = 0.0, proposed_penalty: float = 0.0, proposed_interest: float = 0.0,
        income_items_json: str = "[]",
    ) -> str:
        try:
            nd = _iso(notice_date, "notice_date")
            pd_ = _iso(printed_response_date, "printed_response_date") if printed_response_date else None
            items = json.loads(income_items_json or "[]")
            if not isinstance(items, list):
                raise ValueError("income_items_json must be a JSON array")
        except (ValueError, json.JSONDecodeError) as e:
            return f"ERROR: {e}"
        c = self.c
        c.notice_file, c.notice_code, c.tax_year = notice_file, notice_engine.normalize_code(notice_code), tax_year
        c.notice_date, c.printed_response_date, c.taxpayer_name = nd, pd_, taxpayer_name or None
        c.total_amount_due, c.proposed_tax_increase = total_amount_due, proposed_tax_increase
        c.proposed_penalty, c.proposed_interest, c.income_items = proposed_penalty, proposed_interest, items

        # Deterministic guardrails (not left to the LLM)
        c.human_review_flags = [f for f in c.human_review_flags if not f.startswith("[auto] ")]
        info = notice_engine.get_notice_type(c.notice_code)
        if info is None:
            c.human_review_flags.append(f"[auto] Unsupported notice code '{notice_code}'; a professional should review it.")
        elif info["serious"]:
            c.human_review_flags.append(f"[auto] {c.notice_code} is a serious collection notice; get professional help promptly.")
        if total_amount_due > HIGH_AMOUNT:
            c.human_review_flags.append(f"[auto] Amount due is over ${HIGH_AMOUNT:,.0f}; consider a tax professional.")
        return "recorded (pending taxpayer confirmation)"

    @kernel_function(description="Flag something for human/professional review: unreadable document, unsupported notice, anything unusual.")
    def flag_for_human_review(self, reason: str) -> str:
        self.c.human_review_flags.append(reason)
        return "flagged"


class ExplainPlugin:
    def __init__(self, case: NoticeCase):
        self.c = case

    @kernel_function(description="Save the response deadline (YYYY-MM-DD) and where it came from (e.g. 'printed on notice').")
    def set_deadline(self, due_date: str, source: str) -> str:
        try:
            due = _iso(due_date, "due_date")
        except ValueError as e:
            return f"ERROR: {e}"
        self.c.deadline, self.c.deadline_source = due, source
        left = (date.fromisoformat(due) - date.fromisoformat(self.c.today)).days
        if left < 0:
            self.c.human_review_flags.append(f"[auto] The response deadline {due} has already passed; contact the IRS or a professional now.")
        return f"saved; {left} days remaining as of {self.c.today}"


class VerifyPlugin:
    def __init__(self, case: NoticeCase):
        self.c = case

    @kernel_function(description="Record the as-filed figures read from the taxpayer's return summary. Use 0 for items that are absent.")
    def record_return_summary(
        self, filing_status: str, wages: float, taxable_interest: float, ordinary_dividends: float,
        other_income: float, adjustments: float, itemized_deductions: float, qualifying_children: int,
        other_income_description: str = "", source_file: str = "",
    ) -> str:
        fs = filing_status.lower().strip()
        if fs not in _FS:
            return f"ERROR: filing_status must be one of {sorted(_FS)}"
        self.c.return_summary = dict(
            filing_status=fs, wages=wages, taxable_interest=taxable_interest, ordinary_dividends=ordinary_dividends,
            other_income=other_income, adjustments=adjustments, itemized_deductions=itemized_deductions,
            qualifying_children=qualifying_children, other_income_description=other_income_description,
            source_file=source_file)
        return "recorded"

    @kernel_function(description=(
        "Record the verification outcome. verdict is one of: irs_correct, irs_incorrect, partially_correct, "
        "cannot_determine. income_not_on_return is the total of IRS-reported income that is NOT on the return."))
    def record_verification(self, verdict: str, reasoning: str, income_not_on_return: float,
                            recomputed_tax_increase: float) -> str:
        v = verdict.lower().strip()
        if v not in VERDICTS - {"not_applicable"}:
            return f"ERROR: verdict must be one of {sorted(VERDICTS - {'not_applicable'})}"
        self.c.verification = dict(verdict=v, reasoning=reasoning, income_not_on_return=income_not_on_return,
                                   recomputed_tax_increase=recomputed_tax_increase)
        if v in {"partially_correct", "cannot_determine"}:
            self.c.human_review_flags.append(f"[auto] Verification was '{v}'; have a professional review before responding.")
        return "recorded"


class ResponsePlugin:
    def __init__(self, case: NoticeCase):
        self.c = case

    @kernel_function(description=(
        "Save the drafted response. kind is one of: payment_steps, agree_steps, disagree_letter, partial_letter, "
        "info_checklist. text is the full draft (markdown). Never include an SSN; use a placeholder."))
    def save_response_draft(self, kind: str, text: str) -> str:
        k = kind.lower().strip()
        if k not in RESPONSE_KINDS:
            return f"ERROR: kind must be one of {sorted(RESPONSE_KINDS)}"
        if len(text.strip()) < 40:
            return "ERROR: draft is too short"
        self.c.response_kind, self.c.response_text = k, text
        return "saved"
