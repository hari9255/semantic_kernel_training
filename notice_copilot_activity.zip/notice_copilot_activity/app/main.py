"""Notice Copilot CLI.  Classify -> (confirm) -> Explain -> Verify -> (your decision) -> Respond.

Usage:  python -m app.main --docs sample_docs/cp2000_underreported
"""
import argparse
import asyncio
import logging
import os
import sys
from datetime import date
from pathlib import Path

from dotenv import load_dotenv
from semantic_kernel.connectors.mcp import MCPStdioPlugin

from mcp_server import notice_engine
from .agents import DISCLAIMER, MCP_PLUGIN_NAME, build_agents
from .pii import PiiLogFilter, mask_pii
from .state import NoticeCase

ROOT = Path(__file__).resolve().parent.parent
DECISIONS = {"agree", "disagree", "partial", "unsure"}


def say(who: str, text) -> None:
    print(f"\n[{who}]\n{mask_pii(str(text))}")


async def ask(agent, thread, message: str):
    resp = await agent.get_response(messages=message, thread=thread)
    return resp.message.content, resp.thread


async def run(docs_dir: Path, today: date, out_dir: Path, *, yes: bool = False, decision: str | None = None,
              note: str = "", service=None, input_fn=input) -> NoticeCase:
    case = NoticeCase(today=today.isoformat())
    prompt = lambda q: mask_pii(input_fn(f"\n{q} ").strip())      # SSNs typed by the user never reach an agent

    async with MCPStdioPlugin(
        name=MCP_PLUGIN_NAME, description="IRS notice tools (notice types, deadlines, recalculation, guidance)",
        command=sys.executable, args=["-m", "mcp_server.notice_server"], env={**os.environ, "PYTHONPATH": str(ROOT)},
    ) as mcp_plugin:
        agents = build_agents(case, docs_dir, mcp_plugin, service)

        # 1. Classify, then the taxpayer confirms before anything is relied on
        reply, thread = await ask(agents["classifier"], None,
                                  "Find the IRS notice in the folder, record its facts, summarize, and ask me to confirm.")
        for _ in range(5):
            say("Classifier Agent", reply)
            if case.notice_code is None:
                case.human_review_flags.append("No IRS notice could be identified in the documents.")
                return _finish(case, out_dir)
            ans = "yes" if yes else prompt("Confirm these notice details? (yes / or type corrections):")
            if ans.lower() in {"y", "yes"}:
                case.confirmed = True
                break
            reply, thread = await ask(agents["classifier"], thread,
                                      f"The taxpayer says: {ans}. Apply any correction with record_notice_facts, "
                                      "show the updated summary, and ask to confirm.")
        if not case.confirmed:
            case.human_review_flags.append("Taxpayer did not confirm the extracted notice details.")
            return _finish(case, out_dir)

        # 2. Explain
        reply, _ = await ask(agents["explainer"], None, "Explain this notice and its deadline to me.")
        case.explanation = reply
        say("Explainer Agent", reply)

        # 3. Verify (CP2000 only; other notices have nothing to cross-check in v1)
        info = notice_engine.get_notice_type(case.notice_code) or {}
        if info.get("verifiable"):
            reply, _ = await ask(agents["verifier"], None, "Check the IRS figures against my return summary.")
            say("Verifier Agent", reply)
        else:
            case.verification = {"verdict": "not_applicable", "reasoning": "No cross-check is defined for this notice type in v1."}

        # 4. The decision is the taxpayer's
        while decision not in DECISIONS:
            decision = prompt("How do you want to respond? [agree / disagree / partial / unsure]:").lower()
        case.user_decision = decision
        case.user_note = note if (yes or note) else prompt("Anything to add (documents you have, reasons)? Enter to skip:")

        # 5. Respond
        reply, _ = await ask(agents["responder"], None,
                             f"My decision: {case.user_decision}. My note: {case.user_note or '(none)'}. Draft my response.")
        say("Response Agent", reply)
    return _finish(case, out_dir)


def _finish(case: NoticeCase, out_dir: Path) -> NoticeCase:
    out_dir.mkdir(parents=True, exist_ok=True)
    if case.notice_code:
        v = case.verification or {}
        parts = [f"# {case.notice_code} notice report (tax year {case.tax_year})", f"_Prepared {case.today}_", "",
                 f"**Response deadline:** {case.deadline or case.printed_response_date or 'unknown'} ({case.deadline_source or 'n/a'})", "",
                 "## Explanation", case.explanation or "_not generated_", "",
                 "## Verification", f"**Verdict:** {v.get('verdict', 'n/a')}", v.get("reasoning", ""), "",
                 f"## Draft response ({case.response_kind or 'none'})", case.response_text or "_not generated_", ""]
        if case.human_review_flags:
            parts += ["## Needs human review", *[f"- {f}" for f in case.human_review_flags], ""]
        parts += [f"> {DISCLAIMER}"]
        path = out_dir / f"{case.notice_code.lower()}_report.md"
        path.write_text(mask_pii("\n".join(parts)), encoding="utf-8")
        print(f"\nReport written to {path}")
    if case.deadline:
        left = (date.fromisoformat(case.deadline) - date.fromisoformat(case.today)).days
        print(f"\n>> Respond by {case.deadline} ({left} days from {case.today})")
    if case.human_review_flags:
        print("\n!! HUMAN REVIEW RECOMMENDED:")
        for f in case.human_review_flags:
            print("  -", f)
    print(f"\n{DISCLAIMER}")
    return case


def main() -> None:
    load_dotenv(ROOT / ".env")
    logging.basicConfig(level=logging.WARNING)
    for h in logging.getLogger().handlers:
        h.addFilter(PiiLogFilter())
    ap = argparse.ArgumentParser(description="IRS Notice Decoder & Response Copilot")
    ap.add_argument("--docs", type=Path, default=ROOT / "sample_docs" / "cp2000_underreported")
    ap.add_argument("--today", type=date.fromisoformat, default=date.today(), help="YYYY-MM-DD (for reproducible demos)")
    ap.add_argument("--out", type=Path, default=ROOT / "output")
    ap.add_argument("--yes", action="store_true", help="auto-confirm extracted details")
    ap.add_argument("--decision", choices=sorted(DECISIONS), help="skip the decision prompt")
    ap.add_argument("--note", default="", help="extra context for the response draft")
    a = ap.parse_args()
    if not os.getenv("ANTHROPIC_API_KEY"):
        sys.exit("Set ANTHROPIC_API_KEY (see .env.example).")
    asyncio.run(run(a.docs.resolve(), a.today, a.out.resolve(), yes=a.yes, decision=a.decision, note=a.note))


if __name__ == "__main__":
    main()
