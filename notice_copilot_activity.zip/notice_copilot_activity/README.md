# Notice Copilot: IRS Notice Decoder & Response Copilot

A Semantic Kernel (Python) app on Anthropic Claude, with an MCP tool server. You give it an IRS notice as a PDF
(for example a CP2000 or CP14). It identifies the notice, explains it in plain English, computes the response
deadline, checks the IRS figures against your own return, and drafts your response. It never contacts the IRS.

> General information only. Not legal or tax advice. Always check the response date printed on the notice.

## What it does

```
notice PDF (+ your return summary)
   |
   v
ClassifierAgent --> you confirm the extracted facts
   |
   v
ExplainerAgent  --> plain-English explanation, options, deadline (tools compute the date)
   |
   v
VerifierAgent   --> (CP2000 only) is the IRS right? recomputes the tax with a deterministic engine
   |
   v
you decide: agree / disagree / partial / unsure
   |
   v
ResponseAgent   --> payment steps, or a draft letter + enclosure checklist
   |
   v
output/<notice>_report.md
```

| Agent | Job | Tools |
|---|---|---|
| Classifier | Finds the notice, extracts code, dates, amounts, income table | `list_documents`, `read_document`, `record_notice_facts`, `flag_for_human_review` |
| Explainer | Explains the notice and sets the deadline | `get_case`, MCP `lookup_notice_type`, `calculate_deadline`, `search_irs_guidance`, `set_deadline` |
| Verifier | Compares notice income to your return and recomputes tax | `get_case`, `list/read_document`, `record_return_summary`, MCP `recalculate_tax_difference`, `record_verification` |
| Response | Drafts the response from verified findings and your decision | `get_case`, `save_response_draft`, MCP `search_irs_guidance` |

Each agent only sees the tools in its row. Memory is short-term only: a shared `NoticeCase` plus each agent's
chat thread.

## Supported notices (v1)

CP2000 (full flow with verification), CP14, CP11, CP12, CP501, CP503, CP504 (explain, deadline, response draft).
Anything else is reported as unsupported and flagged for human review. Tax years 2024 and 2025 are supported by
the recalculation engine.

## Guardrails

- Dates and tax numbers come from tools, never from the model.
- SSNs are redacted from PDF text, your typed input, tool arguments and results, and logs.
- You confirm the extracted facts before anything else runs, and you make the agree/disagree decision.
- Deterministic review flags: unsupported code, serious collection notice (CP504), amount over $5,000,
  deadline already passed, inconclusive verification.
- The response agent may not invent grounds. If you disagree but the records show the IRS is right, it produces
  an information checklist instead of a dispute letter.

## Setup

```bash
cd notice_copilot
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # then set ANTHROPIC_API_KEY
```

| Variable | Required | Default |
|---|---|---|
| `ANTHROPIC_API_KEY` | yes | none |
| `ANTHROPIC_MODEL` | no | `claude-sonnet-5-5` |

## Run

Run from the `notice_copilot/` folder. The app starts the MCP server itself.

```bash
# IRS is right: $4,200 of 1099-NEC income is missing from the return
python -m app.main --docs sample_docs/cp2000_underreported --today 2026-11-26

# IRS is wrong: the income was already on the return
python -m app.main --docs sample_docs/cp2000_irs_wrong --today 2026-11-26

# Simple balance-due notice (no verification step)
python -m app.main --docs sample_docs/cp14_balance_due --today 2026-11-26

# Non-interactive
python -m app.main --docs sample_docs/cp2000_irs_wrong --yes --decision disagree --note "I have the 1099-NEC"
```

Options: `--today YYYY-MM-DD` (reproducible deadlines; default is the real date), `--out DIR` (default `output/`),
`--yes` (auto-confirm extracted facts), `--decision {agree,disagree,partial,unsure}`, `--note TEXT`.
Put your own PDFs in a folder: the notice plus, for a CP2000, a summary of the return you filed.

### Expected results for the samples (as of 2026-11-26)

| Sample | Verification | Deadline | Natural decision |
|---|---|---|---|
| `cp2000_underreported` | IRS correct: recomputed tax increase $924.00 matches the notice | 2026-12-09 (13 days) | agree: pay $1,170.07 or ask for a plan |
| `cp2000_irs_wrong` | IRS incorrect: income is on Schedule 1 line 8z, recomputed increase $0 | 2026-12-09 (13 days) | disagree: draft letter with enclosure list |
| `cp14_balance_due` | not applicable | 2026-11-30 (4 days) | agree: pay $1,284.17 |

Wording varies run to run, but the dates and amounts come from tools and should match this table.



## Project layout

```
app/            main.py (CLI + pipeline), agents.py (prompts), plugins.py, state.py (NoticeCase), pii.py
mcp_server/     notice_server.py (MCP), notice_engine.py (notice types, deadlines, recalculation, guidance),
                tax_engine.py (deterministic tax math, reused from the Tax Copilot project)
sample_docs/    generate_samples.py and three fictional sample folders

```


