"""Semantic Kernel agent (Anthropic Claude) that calls the MCP random number tool."""
import asyncio
import os

from semantic_kernel.agents import ChatCompletionAgent
from semantic_kernel.connectors.ai import FunctionChoiceBehavior
from semantic_kernel.connectors.ai.anthropic import (
    AnthropicChatCompletion,
    AnthropicChatPromptExecutionSettings,
)
from semantic_kernel.connectors.mcp import MCPStreamableHttpPlugin
from semantic_kernel.functions import KernelArguments


async def main():
    # Connects to the already-running MCP server and loads its tools as an SK plugin
    async with MCPStreamableHttpPlugin(
        name="RandomTools",
        description="Random number generator tools",
        url=os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000/mcp"),
    ) as random_plugin:

        service = AnthropicChatCompletion(
            ai_model_id=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5"),
            api_key="")

        settings = AnthropicChatPromptExecutionSettings(
            max_tokens=1024,
            function_choice_behavior=FunctionChoiceBehavior.Auto(),
        )

        agent = ChatCompletionAgent(
            service=service,
            name="RandomAgent",
            instructions="You are a helpful assistant. Use the random number tool when asked for random numbers.",
            plugins=[random_plugin],
            arguments=KernelArguments(settings=settings),
        )

        thread = None
        for question in [
            "Give me a random number between 1 and 10.",
            "Now roll two dice for me (1-6 each) and tell me the total.",
        ]:
            print(f"User: {question}")
            response = await agent.get_response(messages=question, thread=thread)
            thread = response.thread
            print(f"Agent: {response}\n")


if __name__ == "__main__":
    asyncio.run(main())