"""MCP server exposing a random number generator tool (runs over stdio)."""
import random

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("RandomNumberServer", host="127.0.0.1", port=8000)


@mcp.tool()
def generate_random_number(min_value: int = 1, max_value: int = 100) -> int:
    """Generate a random integer between min_value and max_value (inclusive)."""
    print("random number tool is called")
    return random.randint(min_value, max_value)


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
